<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Purchaseapi extends CI_Controller {

	public function __construct()
	{
		// Call the CI_Model constructor
		parent::__construct();
		
		$this->load->model(array('purchase_model', 'auditlog_model', 'user_model', 'site_model'));
		$this->load->helper('url');
		$this->load->helper('string');
		$this->load->library('email');
	}
	
	public function approve_draft_order() {
		if (! $this->user_model->is_user_logged_in()) {
			$feedback = array(
					"call_status" => "error",
					"error_code" => "701",
					"error_message" => "User not logged on"
			);
		}
		else {
			$json = file_get_contents('php://input');
				
			$this->auditlog_model->insert_audit_log("purchaseapi", "approve_draft_purchase", $json);
				
			$data = json_decode($json, true);
				
			$insert_purchase = array(
					'vendor_id' => $data['supplier_id'],
					//'currency' => $data['currency'],
					'approver_id' => $this->session->userdata('user_id'),
					'requests_creator' => $this->session->userdata('user_id'),
					'requests_reference' => $data['draft_reference'],
					'date_created' => $data['date_modified'],
					'type' => 'PR',
					'status' => 'P'
			);
				
			$requests_id = $this->purchase_model->insert_requests($insert_purchase);
				
			foreach($data['item_request_list'] as $item_request) {
				$insert_purchase_item_request = array(
						'requests_id' => $requests_id,
						'item_code' => $item_request['item_code'],
						'quantity' => $item_request['quantity'],
						'item_unit' => $item_request['item_unit'],
						'remark' => $item_request['remarks'],
						'cost' => $item_request['cost'],
				);
				$this->purchase_model->insert_requests_item_request($insert_purchase_item_request);
			}
				
			foreach($data['delivery_request_list'] as $delivery_request) {
				$insert_purchase_delivery_request = array(
						'requests_id' => $requests_id,
						'warehouse_id' => $delivery_request['warehouse_id'],
						'remark' => $delivery_request['remark'],
						'requested_date' => date($delivery_request['date']),
						'status' => 'A'
				);
				$requests_delivery_request_id = $this->purchase_model->insert_requests_delivery_request($insert_purchase_delivery_request);
	
				foreach($delivery_request['item_delivery_request_list'] as $item_delivery_request) {
					$insert_item_delivery_request = array(
							'requests_delivery_request_id' => $requests_delivery_request_id,
							'item_code' => $item_delivery_request['item_code'],
							'quantity' => $item_delivery_request['quantity'],
							'item_unit' => $item_delivery_request['item_unit'],
					);
					$this->purchase_model->insert_purchase_delivery_request_items($insert_item_delivery_request);
				}
			}
				
			$update_draft = array(
					'draft_reference' => $data['draft_reference'],
					'status' => 'P'
			);
				
			$this->purchase_model->update_draft_purchase($update_draft);
				
			// feedback API
			$feedback = array(
					"call_status" => "success",
					"draft_reference" => $data['draft_reference'],
					//"order_id" => $order_id,
					//"order_reference" => $order_reference
			);
				
			echo json_encode($feedback);
		}
	}
	
	public function approve_draft_service_order() {
		if (! $this->user_model->is_user_logged_in()) {
			$feedback = array(
					"call_status" => "error",
					"error_code" => "701",
					"error_message" => "User not logged on"
			);
		}/*
		else if (! $this->user_model->is_user_has_access("CUSTOMERSERVICE")) {
		$feedback = array(
		"call_status" => "error",
		"error_code" => "702",
		"error_message" => "User tidak mempunyai hak untuk melakukan hal ini."
		);
		}*/
		else {
			$json = file_get_contents('php://input');
				
			$this->auditlog_model->insert_audit_log("purchaseapi", "approve_draft_service", $json);
				
			$data = json_decode($json, true);
				
			$insert_purchase = array(
					'vendor_id' => $data['supplier_id'],
					//'currency' => $data['currency'],
					'approver_id' => $this->session->userdata('user_id'),
					'requests_creator' => $data['draft_creator'],
					'requests_reference' => $data['draft_reference'],
					'date_created' => $data['date_modified'],
					'type' => 'SR',
					'status' => 'P'
			);
			$requests_id = $this->purchase_model->insert_requests($insert_purchase);
				
			foreach($data['item_request_list'] as $item_request) {
				$insert_purchase_item_request = array(
						'requests_id' => $requests_id,
						'service_name' => $item_request['item_name'],
						'quantity' => $item_request['quantity'],
						'remark' => $item_request['remark'],
						'cost' => $item_request['cost'],
				);
				$this->purchase_model->insert_service_item_request($insert_purchase_item_request);
			}
				
			foreach($data['delivery_request_list'] as $delivery_request) {
				$insert_purchase_delivery_request = array(
						'requests_id' => $requests_id,
						'warehouse_id' => $delivery_request['warehouse_id'],
						'remark' => $delivery_request['remark'],
						'requested_date' => date($delivery_request['date']),
						'status' => 'A'
				);
				$requests_delivery_request_id = $this->purchase_model->insert_requests_delivery_request($insert_purchase_delivery_request);
			}
				
			$update_draft = array(
					'draft_reference' => $data['draft_reference'],
					'status' => 'P'
			);
				
			$this->purchase_model->update_draft_purchase($update_draft);
				
			// feedback API
			$feedback = array(
					"call_status" => "success",
					"draft_reference" => $data['draft_reference']
			);
				
			echo json_encode($feedback);
		}
	}
	
	public function delete_draft_order() {
		if (! $this->user_model->is_user_logged_in()) {
			$feedback = array(
					"call_status" => "error",
					"error_code" => "701",
					"error_message" => "User not logged on"
			);
		}/*
		else if (! $this->user_model->is_user_has_access("CUSTOMERSERVICE")) {
		$feedback = array(
		"call_status" => "error",
		"error_code" => "702",
		"error_message" => "User tidak mempunyai hak untuk melakukan hal ini."
		);
		}*/
		else {
			$data = file_get_contents('php://input');
				
			$update_change = array(
					'draft_reference' => $data,
					'status' => 'X'
			);
			$this->purchase_model->update_draft_purchase($update_change);
				
			// feedback API
			$feedback = array(
					"call_status" => "success",
					"draft_reference" => $data,
			);
		}
	
		echo json_encode($feedback);
	}
	
	public function get_draft_by_id($id) {
		$feedback = array(
			'call_status' => 'success',
			'draft' => $this->purchase_model->get_draft_by_id($id)->row_array()
		);
		
		echo json_encode($feedback);
	}
	
	public function get_draft_purchase_by_draft_reference($draft_reference) {
		$feedback = array(
			'call_status' => 'success',
			'draft_purchase' => $this->purchase_model->get_draft_purchase_by_draft_reference($draft_reference)->row_array(),
			'login_as' => $this->session->userdata('user_id'),
		);
		
		echo json_encode($feedback);
	}
	
	public function get_purchase_by_draft_reference($draft_reference) {
		$feedback = array(
			'call_status' => 'success',
			'purchase' => $this->purchase_model->get_purchase_by_draft_reference($draft_reference)->row_array()
		);
		
		echo json_encode($feedback);
	}
	
	public function get_purchase_request_by_id($id) {
		$feedback = array(
			'call_status' => 'success',
			'purchase_request' => $this->purchase_model->get_purchase_request_by_id($id)->row_array()
		);
		
		echo json_encode($feedback);
	}
	
	public function get_purchase_request_list_by_id($id) {
		$feedback = array(
			'call_status' => 'success',
			'purchase_request_list' => $this->purchase_model->get_purchase_by_approver_id($user_id)->result_array()
		);
		
		echo json_encode($feedback);
	}
	
	public function get_users_list()
	{
		if (! $this->user_model->is_user_logged_in()) {
			$feedback = array(
				"call_status" => "error",
				"error_code" => "701",
				"error_message" => "User not logged on"
			);
		}
		else {
			$feedback = array(
				"call_status" => "success",
				'users_list' => $this->purchase_model->get_users_list()->result_array()
			);
		}
		
		echo json_encode($feedback);
	}
	
	public function get_site_list()
	{
		if (! $this->user_model->is_user_logged_in()) {
			$feedback = array(
				"call_status" => "error",
				"error_code" => "701",
				"error_message" => "User not logged on"
			);
		}
		else {
			$feedback = array(
				"call_status" => "success",
				'site_list' => $this->site_model->get_site_list()->result_array()
			);
		}
		
		echo json_encode($feedback);
	}
	
	public function get_storage_list()
	{
		if(! $this->user_model->is_user_logged_in()) {
			$feedback = array (
				"call_status" => "error",
				"error_code" => "701",
				"error_message" => "User not logged on"
			);
		}
		else{
			$feedback = array(
				"call_status" => "success",
				"storage_list" => $this->purchase_model->get_storage_list()->result_array()
			);
		}
		echo json_encode($feedback);
	}
	
	public function get_bin_list()
	{
		if(! $this->user_model->is_user_logged_in()) {
			$feedback = array (
				"call_status" => "error",
				"error_code" => "701",
				"error_message" => "User not logged on"
			);
		}
		else{
			$feedback = array(
				"call_status" => "success",
				"bin_list" => $this->purchase_model->get_bin_list()->result_array()
			);
		}
		echo json_encode($feedback);
	}

	public function get_batch_list()
	{
		if(! $this->user_model->is_user_logged_in()) {
			$feedback = array (
					"call_status" => "error",
					"error_code" => "701",
					"error_message" => "User not logged on"
			);
		}
		else{
			$feedback = array(
					"call_status" => "success",
					"batch_list" => $this->purchase_model->get_batch_list()->result_array()
			);
		}
		echo json_encode($feedback);
	}
	
	public function get_request() {
		$user_id = $this->session->userdata('user_id');
		$feedback = array(
				'call_status' => 'success',
				'request_list' => $this->purchase_model->get_request()->result_array()
		);
	
		echo json_encode($feedback);
	}
	
	public function get_request_by_approver_id() {
		$user_id = $this->session->userdata('user_id');
	
		$feedback = array(
				'call_status' => 'success',
				'request_list' => $this->purchase_model->get_request_by_approver_id($user_id)->result_array()
		);
	
		echo json_encode($feedback);
	}
	
	public function get_approved_request_by_approver_id() {
		$user_id = $this->session->userdata('user_id');
	
		$feedback = array(
				'call_status' => 'success',
				'request_list' => $this->purchase_model->get_approved_request_by_approver_id($user_id)->result_array()
		);
	
		echo json_encode($feedback);
	}
	
	public function get_active_requests_list() {
		$feedback = array(
				'call_status' => 'success',
				'request_list' => $this->purchase_model->get_active_requests_list()->result_array()
		);
	
		echo json_encode($feedback);
	}
	
	public function get_completed_requests_list() {
		$feedback = array(
				'call_status' => 'success',
				'request_list' => $this->purchase_model->get_completed_requests_list()->result_array()
		);
	
		echo json_encode($feedback);
	}
	
	public function get_active_requests_by_requests_reference($draft_reference) {
		$feedback = array(
				'call_status' => 'success',
				'requests' => $this->purchase_model->get_active_requests_by_requests_reference($draft_reference)->row_array()
		);
	
		echo json_encode($feedback);
	}
	
	public function get_active_item_requests_by_requests_id($requests_id) {
		$item = $this->purchase_model->get_active_item_requests_by_requests_id($requests_id)->result_array();
		
		$received_quantity = array(
			'received_quantity' => 0,	
		);
		foreach ($item as $i){
			array_push($i, $received_quantity);
		}
		$feedback = array(
				'call_status' => 'success',
				'item_requests' => $item
				
		);
	
		echo json_encode($feedback);
	}
	
	public function get_active_delivery_requests_by_requests_id($requests_id) {
		$feedback = array(
				'call_status' => 'success',
				'delivery_requests' => $this->purchase_model->get_active_delivery_requests_by_requests_id($requests_id)->result_array()
		);
	
		echo json_encode($feedback);
	}
	
	public function get_active_delivery_requests_by_delivery_requests_id($delivery_requests_id) {
		$feedback = array(
				'call_status' => 'success',
				'delivery_requests' => $this->purchase_model->get_active_delivery_requests_by_delivery_requests_id($delivery_requests_id)->result_array()
		);
	
		echo json_encode($feedback);
	}
	
	public function get_active_delivery_requests_items_by_requests_delivery_request_id($requests_delivery_request_id) {
		$item = $this->purchase_model->get_active_delivery_requests_items_by_requests_delivery_request_id($requests_delivery_request_id)->result_array();
		$index = 0;
		foreach ($item as $i){
			$item[$index]['received_quantity'] = 0;
			$index+=1;
		}
		
		
		$feedback = array(
				'call_status' => 'success',
				'delivery_requests_items' => $item
		);
	
		echo json_encode($feedback);
	}
	
	public function get_delivered_items_list_by_requests_delivery_request_id($requests_delivery_request_id) {
		$feedback = array(
				'call_status' => 'success',
				'delivered_items_list' => $this->purchase_model->get_delivered_items_list_by_requests_delivery_request_id($requests_delivery_request_id)->result_array()
		);
	
		echo json_encode($feedback);
	}
	
	public function get_active_item_service_requests_by_requests_id($requests_id) {
		$feedback = array(
				'call_status' => 'success',
				'item_requests' => $this->purchase_model->get_active_item_service_requests_by_requests_id($requests_id)->result_array()
		);
	
		echo json_encode($feedback);
	}
	
	public function get_completed_service_by_requests_delivery_request_id($requests_delivery_request_id) {
		$feedback = array(
				'call_status' => 'success',
				'completed_service' => $this->purchase_model->get_completed_service_by_requests_delivery_request_id($requests_delivery_request_id)->result_array()
		);
	
		echo json_encode($feedback);
	}
	
	public function insert_draft_purchase() {
		if (! $this->user_model->is_user_logged_in()) {
			$feedback = array(
				"call_status" => "error",
				"error_code" => "701",
				"error_message" => "User not logged on"
			);
		}
		else if (! $this->user_model->is_user_has_access("CUSTOMERSERVICE")) {
			$feedback = array(
				"call_status" => "error",
				"error_code" => "702",
				"error_message" => "User tidak mempunyai hak untuk melakukan hal ini."
			);
		}
		else {
			$json = file_get_contents('php://input');
			
			$this->auditlog_model->insert_audit_log("purchaseapi", "insert_draft_purchase", $json);
			
			$data = json_decode($json, true);
			
			$insert = array(
				'draft_creator' => $this->session->userdata('user_id'),
				'draft_data' => $json,
				'draft_approver' =>$data['approver_id'],
				'type' => 'P'
			);
			$draft_id = $this->purchase_model->insert_draft_requests($insert);
			
			$draft_reference = $this->purchase_model->generate_draft_reference($draft_id, 'P');
			
			$update = array(
				'draft_id' => $draft_id,
				'draft_reference' => $draft_reference
			);
			$this->purchase_model->update_draft_order($update);
			
			// feedback API
			$feedback = array(
				"call_status" => "success",
				'draft_reference' => $draft_reference
			);
		}
		
		echo json_encode($feedback);
	}
	
	public function insert_draft_service() {
		if (! $this->user_model->is_user_logged_in()) {
			$feedback = array(
				"call_status" => "error",
				"error_code" => "701",
				"error_message" => "User not logged on"
			);
		}
		else if (! $this->user_model->is_user_has_access("CUSTOMERSERVICE")) {
			$feedback = array(
				"call_status" => "error",
				"error_code" => "702",
				"error_message" => "User tidak mempunyai hak untuk melakukan hal ini."
			);
		}
		else {
			$json = file_get_contents('php://input');
			
			$this->auditlog_model->insert_audit_log("purchaseapi", "insert_draft_service", $json);
			
			$data = json_decode($json, true);
			
			$insert = array(
				'draft_creator' => $this->session->userdata('user_id'),
				'draft_data' => $json,
				'draft_approver' =>$data['approver_id'],
				'type' => 'S'
			);
			$draft_id = $this->purchase_model->insert_draft_requests($insert);
			
			$draft_reference = $this->purchase_model->generate_draft_reference($draft_id, 'S');
			
			$update = array(
				'draft_id' => $draft_id,
				'draft_reference' => $draft_reference
			);
			$this->purchase_model->update_draft_order($update);
			
			// feedback API
			$feedback = array(
				"call_status" => "success",
				'draft_reference' => $draft_reference
			);
		}
		
		echo json_encode($feedback);
	}
	
	public function insert_delivered_items (){
		$data = json_decode(file_get_contents('php://input'),true);
		
		foreach ($data as $goodRecieved){
			$batch = array(
				'batch_reference' => @$goodRecieved['batch_reference'],
				'item_code' => @$goodRecieved['item_code'],
				'production_date' => @$goodRecieved['production_date'],
				'expired_date' => @$goodRecieved['expired_date'],
				'good_receive_date' => @$goodRecieved['date_recieved'],	
				'remark' => @$goodRecieved['remark'],	
			);
			$batch_id = $this->purchase_model->insert_batchs($batch);
			$insert_good_recieved = array(
				'requests_delivery_request_id' => $goodRecieved['requests_delivery_request_id'] ,
				'item_code' => $goodRecieved['item_code'],
				'item_unit' => $goodRecieved['item_unit'],
				'quantity' => $goodRecieved['quantity'],
				'date_recieved' => $goodRecieved['date_recieved'],	
				'site_id' => @$goodRecieved['site_id'],	
				'storage_id' => @$goodRecieved['storage_id'],
				'bin_id' => @$goodRecieved['bin_id'],	
				'batch_id' => @$batch_id,	
				'remark' => @$goodRecieved['remark'],	
			);
			$purchase_delivered_item_id = $this->purchase_model->insert_delivered_items($insert_good_recieved);
			$inventory = array(
				'purchase_delivered_item_id' => $purchase_delivered_item_id,
				'item_code' => $goodRecieved['item_code'],
				'site_id' => @$goodRecieved['site_id'],	
				'storage_id' => @$goodRecieved['storage_id'],
				'bin_id' => @$goodRecieved['bin_id'],	
				'batch_id' => @$batch_id,	
				'quantity' => @$goodRecieved['quantity'],
			);
			$this->purchase_model->insert_inventory_stock($inventory);
		}
		$feedback = array(
			"call_status" => "success",
			"data" => $data
		);
		echo json_encode($feedback);
	}
	
	public function insert_completed_service (){
		$serviceExecution = json_decode(file_get_contents('php://input'),true);
		
		$insert_service_execution = array(
			'requests_delivery_request_id' => $serviceExecution['requests_delivery_request_id'] ,
			'confirmed_by' => $this->session->userdata('user_id'),
			'date_completed' => $serviceExecution['date_completed'] ,
			'remark' => $serviceExecution['remark'] ,
		);
		$complete = $this->purchase_model->insert_completed_service($insert_service_execution);
		
		$feedback = array(
			"call_status" => "success",
			"completed_service" => $complete
		);
		echo json_encode($feedback);
	}
	
	public function is_user_approver() {
		$data = json_decode(file_get_contents('php://input'), true);
		$user_id = $this->session->userdata('user_id');
		$num_rows = $this->purchase_model->get_draft_by_id_and_approver_id($data['draft_id'], $user_id)->num_rows();
		
		if($num_rows){
			$approver = true;
		}
		else{
			$user = $this->purchase_model->get_users_by_user_id($user_id)->row()->max_limit;
			$users = $this->purchase_model->get_users_by_user_id($data['draft_approver'])->row()->max_limit;
			if($user > $users){
				$approver = true;
			}else{
				$approver = false;
			}
		}
		
		$feedback = array(
			'call_status' => 'success',
			'approver' => $approver,
			'num_row' => $num_rows,
			'data' => $data,
		);
		
		echo json_encode($feedback);
	}
	
	public function is_purchase_requests_complete($requests_id) {
		$requests_active = $this->purchase_model->get_purchase_delivery_requests_by_requests_id($requests_id)->result_array();
		$requests_complete = $this->purchase_model->get_completed_purchase_delivery_requests_by_requests_id($requests_id)->result_array();
	
		if($requests_active == $requests_complete){
			$update = array(
					'requests_id' => $requests_id,
					'date_modified' => date('Y-m-d'),
					'status' => 'C',
			);
			$this->purchase_model->update_purchase_request_to_complete_purchase_request($update);
		}
	
		$feedback = array(
				'call_status' => 'success',
		);
	
		echo json_encode($feedback);
	}
	
	public function need_changed_draft_order() {
		if (! $this->user_model->is_user_logged_in()) {
			$feedback = array(
					"call_status" => "error",
					"error_code" => "701",
					"error_message" => "User not logged on"
			);
		}/*
		else if (! $this->user_model->is_user_has_access("CUSTOMERSERVICE")) {
		$feedback = array(
		"call_status" => "error",
		"error_code" => "702",
		"error_message" => "User tidak mempunyai hak untuk melakukan hal ini."
		);
		}*/
		else {
			$data = json_decode(file_get_contents('php://input'), true);
				
			$update_change = array(
					'draft_reference' => $data['draft_reference'],
					'status' => 'C'
			);
				
			$this->purchase_model->update_draft_purchase($update_change);
				
			// feedback API
			$feedback = array(
					"call_status" => "success",
					"draft_reference" => $data['draft_reference'],
			);
		}
	
		echo json_encode($feedback);
	}
	
	public function send_email(){
		//$random = random_string('numeric', 3);
		//$filename = "REPORT$random - PURCHASE";
		$filename = "test";
		$result = $this->purchase_model->get_users_list();           
		$data['purchases'] = $result;

		$pdfFilePath = FCPATH."/docs/".$filename.".pdf";
		$data['page_title'] = 'REPORT';
		
		//if (file_exists($pdfFilePath) == FALSE) {
			ini_set('memory_limit','32M'); 
			$html = $this->load->view('pdf', $data, true);
			 
			$this->load->library('pdf');
			$pdf = $this->pdf->load('','A4',9,'dejavusans');
			$pdf->SetFooter('WVI'.'|{PAGENO}|'.date(DATE_RFC822));
			$pdf->WriteHTML($html); 
			
			$pdf->Output($pdfFilePath, 'F'); 
			$pdf->Output();
			
		//}

	}
	
	public function update_draft_order() {
		if (! $this->user_model->is_user_logged_in()) {
			$feedback = array(
				"call_status" => "error",
				"error_code" => "701",
				"error_message" => "User not logged on"
			);
		}/*
		else if (! $this->user_model->is_user_has_access("CUSTOMERSERVICE")) {
			$feedback = array(
				"call_status" => "error",
				"error_code" => "702",
				"error_message" => "User tidak mempunyai hak untuk melakukan hal ini."
			);
		}*/
		else {
			$json = file_get_contents('php://input');
			
			//$this->auditlog_model->insert_audit_log("purchaseapi", "insert_draft_purchase", $json);
			
			$data = json_decode($json, true);
			
			$update = array(
				'draft_data' => $json,
				'status' => 'A',
				'draft_reference' => $data['draft_reference'],
				//'product_type' => $array['product_type']
			);
			$this->purchase_model->update_draft_purchase($update);
			
			// feedback API
			$feedback = array(
				"call_status" => "success",
				'draft_reference' => $data['draft_reference'],
			);
		}
		
		echo json_encode($feedback);
	}
	
	public function update_completed_delivery_request() {
		if (! $this->user_model->is_user_logged_in()) {
			$feedback = array(
				"call_status" => "error",
				"error_code" => "701",
				"error_message" => "User not logged on"
			);
		}/*
		else if (! $this->user_model->is_user_has_access("CUSTOMERSERVICE")) {
		$feedback = array(
		"call_status" => "error",
		"error_code" => "702",
		"error_message" => "User tidak mempunyai hak untuk melakukan hal ini."
		);
		}*/
		else {
			$json = file_get_contents('php://input');
			
			//$this->auditlog_model->insert_audit_log("purchaseapi", "insert_draft_purchase", $json);
			
			$deliveryRequestsId = json_decode($json, true);
			
			$update = array(
				'requests_delivery_request_id' => $deliveryRequestsId,
				'status' => 'C',
			);
			$this->purchase_model->update_completed_delivery_request($update);
			
			// feedback API
			$feedback = array(
				"call_status" => "success",
			);
		}
		
		echo json_encode($feedback);
	}
	
	public function update_locations_delivered_request_item() {
		if (! $this->user_model->is_user_logged_in()) {
			$feedback = array(
				"call_status" => "error",
				"error_code" => "701",
				"error_message" => "User not logged on"
			);
		}/*
		else if (! $this->user_model->is_user_has_access("CUSTOMERSERVICE")) {
		$feedback = array(
		"call_status" => "error",
		"error_code" => "702",
		"error_message" => "User tidak mempunyai hak untuk melakukan hal ini."
		);
		}*/
		else {
			$json = file_get_contents('php://input');
			
			//$this->auditlog_model->insert_audit_log("purchaseapi", "insert_draft_purchase", $json);
			
			$data = json_decode($json, true);
			
			$update = array(
				'purchase_delivered_item_id' => $data['purchase_delivered_item_id'],
				'site_id' => $data['site_id'],
				'storage_id' => $data['storage_id'],
				'bin_id' => $data['bin_id'],
			);
			$this->purchase_model->update_locations_delivered_request_item($update);
			$this->purchase_model->update_locations_inventory_stock($update);
			
			// feedback API
			$feedback = array(
				"call_status" => "success",
				'data' => $update,
			);
		}
		
		echo json_encode($feedback);
	}
	
	public function update_batch_delivered_request_item() {
		if (! $this->user_model->is_user_logged_in()) {
			$feedback = array(
					"call_status" => "error",
					"error_code" => "701",
					"error_message" => "User not logged on"
			);
		}/*
		else if (! $this->user_model->is_user_has_access("CUSTOMERSERVICE")) {
		$feedback = array(
		"call_status" => "error",
		"error_code" => "702",
		"error_message" => "User tidak mempunyai hak untuk melakukan hal ini."
		);
		}*/
		else {
			$json = file_get_contents('php://input');
			
			//$this->auditlog_model->insert_audit_log("purchaseapi", "insert_draft_purchase", $json);
				
			$data = json_decode($json, true);
				
			$update = array(
					'batch_id' => $data['batch_id'],
					'batch_reference' => $data['batch_reference'],
					'production_date' => $data['production_date'],
					'expired_date' => $data['expired_date']
			);
			$this->purchase_model->update_batch_delivered_request_item($update);
				
			// feedback API
			$feedback = array(
					"call_status" => "success",
					'data' => $update,
			);
		}
	
		echo json_encode($feedback);
	}
	
	public function update_remark_delivered_request_item() {
		if (! $this->user_model->is_user_logged_in()) {
			$feedback = array(
				"call_status" => "error",
				"error_code" => "701",
				"error_message" => "User not logged on"
			);
		}/*
		else if (! $this->user_model->is_user_has_access("CUSTOMERSERVICE")) {
		$feedback = array(
		"call_status" => "error",
		"error_code" => "702",
		"error_message" => "User tidak mempunyai hak untuk melakukan hal ini."
		);
		}*/
		else {
			$json = file_get_contents('php://input');
			
			//$this->auditlog_model->insert_audit_log("purchaseapi", "insert_draft_purchase", $json);
			
			$data = json_decode($json, true);
			
			$update = array(
				'purchase_delivered_item_id' => $data['purchase_delivered_item_id'],
				'remark' => $data['remark'],
			);
			$this->purchase_model->update_remark_delivered_request_item($update);
			
			// feedback API
			$feedback = array(
				"call_status" => "success",
				'data' => $update,
			);
		}
		
		echo json_encode($feedback);
	}
	
	public function update_service_request_to_complete_service_request() {
		if (! $this->user_model->is_user_logged_in()) {
			$feedback = array(
				"call_status" => "error",
				"error_code" => "701",
				"error_message" => "User not logged on"
			);
		}/*
		else if (! $this->user_model->is_user_has_access("CUSTOMERSERVICE")) {
		$feedback = array(
		"call_status" => "error",
		"error_code" => "702",
		"error_message" => "User tidak mempunyai hak untuk melakukan hal ini."
		);
		}*/
		else {
			$json = file_get_contents('php://input');
			
			//$this->auditlog_model->insert_audit_log("purchaseapi", "insert_draft_purchase", $json);
			
			$requestsReference = json_decode($json, true);
			
			$update = array(
				'requests_reference' => $json,
				'date_modified' => date('Y-m-d'),
				'status' => 'C',
			);
			$this->purchase_model->update_service_request_to_complete_service_request($update);
			
			// feedback API
			$feedback = array(
				"call_status" => "success",
			);
		}
		
		echo json_encode($feedback);
	}
	
	
	
	
	
}
